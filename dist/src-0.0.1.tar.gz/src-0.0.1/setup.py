from setuptools import setup, find_packages

setup(
    name='src',
    version="0.0.1",
    description =' it a wineq package',
    author='ReshmaChikate5',
    packages= find_packages(),
    license='MIT'
)